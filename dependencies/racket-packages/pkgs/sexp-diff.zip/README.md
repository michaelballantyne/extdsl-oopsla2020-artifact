sexp-diff
=========

diffs s-expressions based on Levenshtein-like edit distance.
Ported more or less directly from Michael Weber's Common Lisp implementation.

To install: `raco pkg install sexp-diff`

[Docs](http://pkg-build.racket-lang.org/doc/sexp-diff@sexp-diff/index.html)

This code is in the Public Domain.
