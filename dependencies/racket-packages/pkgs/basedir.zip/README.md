This is a racket library for convenient adherence to the XDG basedir standard.

Install with `raco pkg install basedir`.

Documentation is [online](http://docs.racket-lang.org/basedir/index.html), or
available by running `raco docs basedir` after installing.

