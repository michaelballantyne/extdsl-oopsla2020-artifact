kw-utils [![Build Status](https://travis-ci.org/AlexKnauth/kw-utils.png?branch=master)](https://travis-ci.org/AlexKnauth/kw-utils)
========

misc kw utils

main documentation: http://pkg-build.racket-lang.org/doc/kw-utils/index.html

- kw-lists-lambda: http://docs.racket-lang.org/kw-utils/kw-lists-lambda_scrbl.html

- kw-hash-lambda etc: http://pkg-build.racket-lang.org/doc/kw-utils/kw-hash_scrbl.html

- keyword-apply/sort: http://pkg-build.racket-lang.org/doc/kw-utils/keyword-apply-sort_scrbl.html

- arity+keywords: http://pkg-build.racket-lang.org/doc/kw-utils/arity_keywords_scrbl.html

- map with keywords: http://pkg-build.racket-lang.org/doc/kw-utils/kw-map_scrbl.html

- partial application: http://pkg-build.racket-lang.org/doc/kw-utils/Partial_application_with_keywords.html

- curried map: http://pkg-build.racket-lang.org/doc/kw-utils/Creating_functions_that_map_over_lists.html

