[![Build Status](https://travis-ci.org/greghendershott/rackjure.png?branch=master)](https://travis-ci.org/greghendershott/rackjure)
[![raco pkg install rackjure](https://img.shields.io/badge/raco_pkg_install-rackjure-aa00ff.svg)](http:pkgs.racket-lang.org/#[rackjure])
[![Documentation](https://img.shields.io/badge/read-documentation-blue.svg)](http://pkg-build.racket-lang.org/doc/rackjure@rackjure/index.html)
![MIT License](https://img.shields.io/badge/license-MIT-118811.svg)

# #lang rackjure

Provide a few Clojure-inspired ideas in Racket.

Where Racket and Clojure conflict, prefer Racket.

[Documentation](http://pkg-build.racket-lang.org/doc/rackjure/index.html).

[MIT license](https://github.com/greghendershott/rackjure/blob/master/rackjure/LICENSE).
