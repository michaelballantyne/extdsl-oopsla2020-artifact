[![Build Status,](https://img.shields.io/travis/jsmaniac/auto-syntax-e/master.svg)](https://travis-ci.org/jsmaniac/auto-syntax-e)
[![Coverage Status,](https://img.shields.io/codecov/c/github/jsmaniac/auto-syntax-e/master.svg)](https://codecov.io/gh/jsmaniac/auto-syntax-e)
[![Build Stats,](https://img.shields.io/badge/build-stats-blue.svg)](http://jsmaniac.github.io/travis-stats/#jsmaniac/auto-syntax-e)
[![Online Documentation,](https://img.shields.io/badge/docs-online-blue.svg)](http://docs.racket-lang.org/auto-syntax-e/)
[![Maintained as of 2018,](https://img.shields.io/maintenance/yes/2018.svg)](https://github.com/jsmaniac/auto-syntax-e/issues)
[![License: CC0 v1.0.](https://img.shields.io/badge/license-CC0-blue.svg)](https://creativecommons.org/publicdomain/zero/1.0/)

auto-syntax-e
=============

For racket syntax pattern variables: instead of raising an error, `x` is roughly equivalent to `(syntax->datum #'x)`.