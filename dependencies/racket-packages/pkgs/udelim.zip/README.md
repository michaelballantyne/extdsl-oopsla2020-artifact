This is Racket library for adding extra types of parethesis and new string delimiters,
for conveniently wrapping them for macro invocations, and for reading strings full of
alternative types of syntax.

Online documentation is [here](http://docs.racket-lang.org/udelim/index.html).
After installing with `raco pkg install udelim`, documentation
is available locally by running `raco docs udelim`.

